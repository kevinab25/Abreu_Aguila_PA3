import java.time.chrono.IsoEra;

public class Tester extends SavingsAccount {

public static void main( String[] args){
    int total;
    SavingsAccount saver1 = new SavingsAccount(2000.0);
    SavingsAccount saver2 = new SavingsAccount(3000.0);

    SavingsAccount.modifyInterestRate(0.04);
    System.out.println("This is the Balance for Saver 1: ");

    for(int i=0; i<12; i++){
        saver1.calculateMonthlyInterest();
        System.out.println("Month " + (i+1) + " : " + String.format("%.2f", saver1.getSavingsBalance()));
    }
System.out.println("");
    System.out.println("This is the balance for Saver 2: ");
    for(int k=0; k<12; k++){
        saver2.calculateMonthlyInterest();
        System.out.println("Month " + (k+1) + " : " + String.format("%.2f", saver2.getSavingsBalance()));
    }

    SavingsAccount.modifyInterestRate(0.05);
    System.out.println("After changing the annual interest to 5% for Saver 1:");
    for(int i=0; i<12; i++){
        saver1.calculateMonthlyInterest();
        System.out.println("Month " + (i+1) + " : " + String.format("%.2f", saver1.getSavingsBalance()));
    }

    System.out.println("After changing the annual interest to 5% for Saver 2:");
    for(int k=0; k<12; k++){
        saver2.calculateMonthlyInterest();
        System.out.println("Month " + (k+1) + " : " + String.format("%.2f", saver2.getSavingsBalance()));
    }

}
}
