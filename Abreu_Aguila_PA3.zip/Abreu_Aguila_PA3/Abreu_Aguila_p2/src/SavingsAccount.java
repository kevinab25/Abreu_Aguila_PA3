import java.util.*;
import java.lang.System;

public class SavingsAccount {
    public static double annualInterestRate;
    private double savingsBalance;

    public SavingsAccount(){

    }

    public SavingsAccount(double savingsBalance){
        this.savingsBalance = savingsBalance;
    }

    public double getSavingsBalance(){
        return this.savingsBalance;
    }
    public void calculateMonthlyInterest(){
        double monthlyInt;
        monthlyInt = (double)(this.savingsBalance * annualInterestRate / 12);
        this.savingsBalance += monthlyInt;
    }

    public static double modifyInterestRate(double newInterest){
        annualInterestRate = newInterest;
        return annualInterestRate;
    }

}
