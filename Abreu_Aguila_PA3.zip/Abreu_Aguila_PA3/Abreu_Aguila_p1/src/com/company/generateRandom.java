package com.company;
import java.util.Random;
public class generateRandom {
private int rdm;


    public static void main(String args[]) {
        // create instance of Random class
        Random rand = new Random();

        int x = rand.nextInt(9);
        System.out.println(x);

        return;
    }
}