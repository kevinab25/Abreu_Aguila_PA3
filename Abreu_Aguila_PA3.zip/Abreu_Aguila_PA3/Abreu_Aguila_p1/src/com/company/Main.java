package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner sc = new Scanner(System.in);
        Calculator student1 = new Calculator();


         boolean session = true;
        while(session) {
            System.out.println("Please select level (1-4)");
            int level = sc.nextInt();
            System.out.println("Please select an arithmetic(1-5)");
            int arith = sc.nextInt();

            student1.selectLevel(level);
            student1.selectArith(arith);

            System.out.println("");
            System.out.println("Would you like to start a new session? (Y/N)");
            String sess = sc.next();
            if(sess.equalsIgnoreCase("N")){
                session = false;
                System.out.println("Thank you for participating!");
            }

        }
        //testers
        //student1.multQuestions();
        //student1.addQuestions();
        //student1.subQuestions();
        //student1.divQuestions();

    }
}

