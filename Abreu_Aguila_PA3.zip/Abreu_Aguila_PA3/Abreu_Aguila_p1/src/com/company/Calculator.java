package com.company;
import java.util.Random;
import java.util.Scanner;

public class Calculator {
    public double num1;
    public double num2;
    public double ans;
    Scanner sc = new Scanner(System.in);
    Random rand = new Random();
    public int bound;

    public Calculator(){

    }

    public void selectLevel(int l) {
        int level = l;
        this.bound = bound;
        if (level == 1)
            bound = 10;
        else if (level == 2)
            bound = 100;
        else if (level == 3)
            bound = 1000;
        else if (level == 4)
            bound = 10000;
    }

    public void selectArith(int a){
        if(a == 1)
            addQuestions();
        else if(a == 2)
            multQuestions();
        else if(a == 3)
            subQuestions();
        else if(a == 4)
            divQuestions();
        else if(a == 5)
            randQuestions();
        else{
            System.out.println("Not a valid option.Please try again.");
        }

    }

    public int getLevel(){
        return bound;
    }

    public double getNum1(){
        return num1;
    }

    public double getNum2(){
        return num2;
    }

    public void printCorrect(){
        int option = rand.nextInt(4);
        switch(option){
            case 0:
                System.out.println("Very good!");
                break;
            case 1:
                System.out.println("Excellent!");
                break;
            case 2:
                System.out.println("Nice work!");
                break;
            case 3:
                System.out.println("Keep up the good work!");
                break;

        }
    }

    public void printIncorrect(){
        int option = rand.nextInt(4);
        switch (option){
            case 0:
                System.out.println("No. Please try again.");
                break;
            case 1:
                System.out.println("Wrong. Please try one more time.");
                break;
            case 2:
                System.out.println("Don't give up!");
                break;
            case 3:
                System.out.println("Nope. Keep trying!");
                break;

        }
    }

    public void addQuestions(){
        this.num1 = rand.nextInt(getLevel());
        this.num2 = rand.nextInt(getLevel());
        ans = num1 + num2;
        int corrCounter = 0, incCounter = 0, questCounter = 0;
        boolean tracker = true;

        //System.out.println("How much is " + num1 + " times " + num2 + " ?");
        double userAns;
        for(int i=0; i<10; i++) {
            num1 = rand.nextInt(getLevel());
            num2 = rand.nextInt(getLevel());
            ans = num1 + num2;
            System.out.println("How much is " + num1 + " plus " + num2 + " ?");
            userAns = sc.nextDouble();

            while (tracker) {
                if (userAns != ans) {
                    printIncorrect();
                    incCounter ++; questCounter ++;
                    System.out.println("How much is " + num1 + " plus " + num2 + " ?");
                    userAns = sc.nextDouble();
                } else if (userAns == ans) {
                    printCorrect();
                    corrCounter ++; questCounter ++;
                    tracker = false;
                }
            }


            tracker = true;

        }
        double percent = ((double) corrCounter / (double) questCounter) * 100;
        System.out.println(corrCounter + " correct answers.");
        System.out.println(incCounter + " incorrect answers.");
        System.out.printf("You were %.2f  correct.\n", percent);

        if(percent < 75) {
            System.out.println("Please ask your teacher for extra help.");
        } else {
            System.out.println("Congratulations, you are ready to go to the next level!");
        }
    }

    public void multQuestions(){
        this.num1 = rand.nextInt(getLevel());
        this.num2 = rand.nextInt(getLevel());
        ans = num1 * num2;
        int corrCounter = 0, incCounter = 0, questCounter = 0;
        boolean tracker = true;

        //System.out.println("How much is " + num1 + " times " + num2 + " ?");
        double userAns;
        for(int i=0; i<10; i++) {
            num1 = rand.nextInt(getLevel());
            num2 = rand.nextInt(getLevel());
            ans = num1 * num2;
            System.out.println("How much is " + num1 + " times " + num2 + " ?");
            userAns = sc.nextDouble();

            while (tracker) {
                if (userAns != ans) {
                    printIncorrect();
                    incCounter ++; questCounter ++;
                    System.out.println("How much is " + num1 + " times " + num2 + " ?");
                    userAns = sc.nextDouble();
                } else if (userAns == ans) {
                    printCorrect();
                    corrCounter ++; questCounter ++;
                    tracker = false;
                }
            }


            tracker = true;

        }
        double percent = ((double) corrCounter / (double) questCounter) * 100;
        System.out.println(corrCounter + " correct answers.");
        System.out.println(incCounter + " incorrect answers.");
        System.out.printf("You were %.2f  correct.\n", percent);

        if(percent < 75) {
            System.out.println("Please ask your teacher for extra help.");
        } else {
            System.out.println("Congratulations, you are ready to go to the next level!");
        }
    }

    public void subQuestions(){
        this.num1 = rand.nextInt(getLevel());
        this.num2 = rand.nextInt(getLevel());
        ans = num1 - num2;
        int corrCounter = 0, incCounter = 0, questCounter = 0;
        boolean tracker = true;

        //System.out.println("How much is " + num1 + " times " + num2 + " ?");
        double userAns;
        for(int i=0; i<10; i++) {
            num1 = rand.nextInt(getLevel());
            num2 = rand.nextInt(getLevel());
            ans = num1 - num2;
            System.out.println("How much is " + num1 + " minus " + num2 + " ?");
            userAns = sc.nextDouble();

            while (tracker) {
                if (userAns != ans) {
                    printIncorrect();
                    incCounter ++; questCounter ++;
                    System.out.println("How much is " + num1 + " minus " + num2 + " ?");
                    userAns = sc.nextDouble();
                } else if (userAns == ans) {
                    printCorrect();
                    corrCounter ++; questCounter ++;
                    tracker = false;
                }
            }


            tracker = true;

        }
        double percent = ((double) corrCounter / (double) questCounter) * 100;
        System.out.println(corrCounter + " correct answers.");
        System.out.println(incCounter + " incorrect answers.");
        System.out.printf("You were %.2f  correct.\n", percent);

        if(percent < 75) {
            System.out.println("Please ask your teacher for extra help.");
        } else {
            System.out.println("Congratulations, you are ready to go to the next level!");
        }
    }

    public void divQuestions(){
        this.num1 = rand.nextInt(getLevel());
        this.num2 = rand.nextInt(getLevel());
        ans = num1 / num2;
        int corrCounter = 0, incCounter = 0, questCounter = 0;
        boolean tracker = true;

        //System.out.println("How much is " + num1 + " times " + num2 + " ?");
        double userAns;
        for(int i=0; i<10; i++) {
            num1 = rand.nextInt(getLevel());
            num2 = rand.nextInt(getLevel());
            boolean isIt = true;
            while( isIt) {
                if((num2 != 0) && (num1%num2 == 0)) {
                    ans = num1 / num2;
                    isIt = false;
                }
                else{
                    num2 = rand.nextInt(getLevel());
                }
            }


            System.out.println("How much is " + num1 + " divided by " + num2 + " ?");
            userAns = sc.nextDouble();

            while (tracker) {
                if (userAns != ans) {
                    printIncorrect();
                    incCounter ++; questCounter ++;
                    System.out.println("How much is " + num1 + " divided by " + num2 + " ?");
                    userAns = sc.nextDouble();
                } else if (userAns == ans) {
                    printCorrect();
                    corrCounter ++; questCounter ++;
                    tracker = false;
                }
            }


            tracker = true;

        }
        double percent = ((double) corrCounter / (double) questCounter) * 100;
        System.out.println(corrCounter + " correct answers.");
        System.out.println(incCounter + " incorrect answers.");
        System.out.printf("You were %.2f  correct.\n", percent);

        if(percent < 75) {
            System.out.println("Please ask your teacher for extra help.");
        } else {
            System.out.println("Congratulations, you are ready to go to the next level!");
        }
    }

    public void randQuestions(){
        for(int i=0; i<10; i++){
        int x = rand.nextInt(5);
        switch (x){
            case 1: {
                num1 = rand.nextInt(getLevel());
                num2 = rand.nextInt(getLevel());
                ans = num1 + num2;
                System.out.println("How much is " + num1 + " plus " + num2 + " ?");
                double userAns = sc.nextDouble();
                boolean tracker = true;
                int questCounter = 0, incCounter = 0, corrCounter = 0;

                while (tracker) {
                    if (userAns != ans) {
                        printIncorrect();
                        incCounter++;
                        questCounter++;
                        System.out.println("How much is " + num1 + " plus " + num2 + " ?");
                        userAns = sc.nextDouble();
                    } else if (userAns == ans) {
                        printCorrect();
                        corrCounter++;
                        questCounter++;
                        tracker = false;
                    }
                }
            }
            case 2: {
                num1 = rand.nextInt(getLevel());
                num2 = rand.nextInt(getLevel());
                ans = num1 * num2;
                System.out.println("How much is " + num1 + " times " + num2 + " ?");
                double userAns = sc.nextDouble();
                boolean tracker = true;
                int questCounter = 0, incCounter = 0, corrCounter = 0;

                while (tracker) {
                    if (userAns != ans) {
                        printIncorrect();
                        incCounter++;
                        questCounter++;
                        System.out.println("How much is " + num1 + " times " + num2 + " ?");
                        userAns = sc.nextDouble();
                    } else if (userAns == ans) {
                        printCorrect();
                        corrCounter++;
                        questCounter++;
                        tracker = false;
                    }
                }
            }
            case 3: {
                num1 = rand.nextInt(getLevel());
                num2 = rand.nextInt(getLevel());
                ans = num1 - num2;
                System.out.println("How much is " + num1 + " minus " + num2 + " ?");
                double userAns = sc.nextDouble();
                boolean tracker =true;
                int questCounter =0 ,incCounter=0, corrCounter=0;

                while (tracker) {
                    if (userAns != ans) {
                        printIncorrect();
                        incCounter++;
                        questCounter++;
                        System.out.println("How much is " + num1 + " minus " + num2 + " ?");
                        userAns = sc.nextDouble();
                    } else if (userAns == ans) {
                        printCorrect();
                        corrCounter++;
                        questCounter++;
                        tracker = false;
                    }
                }
            }
            case 4: {
                num1 = rand.nextInt(getLevel());
                num2 = rand.nextInt(getLevel());
                ans = num1 / num2;
                boolean isIt = true;
                while( isIt) {
                    if((num2 != 0) && (num1%num2 == 0)) {
                        ans = num1 / num2;
                        isIt = false;
                    }
                    else{
                        num2 = rand.nextInt(getLevel());
                    }
                }

                System.out.println("How much is " + num1 + " divided by " + num2 + " ?");
                double userAns = sc.nextDouble();
                boolean tracker =true;
                int questCounter =0 ,incCounter=0, corrCounter=0;

                while (tracker) {
                    if (userAns != ans) {
                        printIncorrect();
                        incCounter++;
                        questCounter++;
                        System.out.println("How much is " + num1 + " divided by " + num2 + " ?");
                        userAns = sc.nextDouble();
                    } else if (userAns == ans) {
                        printCorrect();
                        corrCounter++;
                        questCounter++;
                        tracker = false;
                    }
                }
            }
        }
        }
    }
}

